num1 = int(input("Enter First Number: ")
num2 = int(input("Enter Second Number: ")

sum = num1+num2

print(""Sum of {0} and {1} is {2}" .format(num1, num2, sum))
