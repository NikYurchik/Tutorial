def maximum(a, b):
      
    if a >= b:
        return a
    else:
        return b
      
n1 = int(input("Enter First Number: ") 
n2 = int(input("Enter Second Number: ")

print(maximum(n1,n2))
