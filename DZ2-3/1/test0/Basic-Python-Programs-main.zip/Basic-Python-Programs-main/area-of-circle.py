
def findArea(r):
    PI = 3.142
    return PI * (r*r)
  
print("Area is %.2f" % findArea(5))
