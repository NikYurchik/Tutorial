# Basic-Python-Programs
This repository will contain basic python programming questions and their solutions.

# Do give us a Star 

# Contributions

- Add a new program which don't exist earlier
- It should be in .py extenstion
- Please run the program and check if there are no errors before making the PR
- Review other PR's as well
- No Spamming allowed, make sure to include all programs in one PR.
