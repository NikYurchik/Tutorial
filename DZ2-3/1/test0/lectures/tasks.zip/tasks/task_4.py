"""
4. Напишіть функцію гри, що буде загадувати число від 1 до 100, а Ви маєте його вгадати. Після кожного введення програма Вам може підказувати, чи загадане число більше чи менше введеного. Також можна рахувати і в кінці вивести кількість спроб, за яку користувач вгадав число. Підказка: використовуйте бібліотеку random (а саме метод randint)
4*. Аналогічно зробіь функцію гри, де Ви загадуєте число від 1 до 100 (вводячи його), а комп'ютер має його вгадати за 10 спроб (без Ваших підказок). 
Простіший варіант: комп'ютер не пам'ятає, які числа він називав як варіанти до того (під час однієї гри). Використовуйте random.randint
Складніший варіант: комп'ютер пам'ятає, що він пробував вгадати до того, і не пробує повторюватися, коли вгадує число. Використовуйте random.sample
"""
from random import randint, sample

def task_4():

    def game():
        count = 0
        goal = randint(1, 100)  # отримуємо випадкове ціле число від 1 до 100
        while True:
            answer = int(input(f"Вгадайте задумане число від 0 до 100: "))
            count += 1
            if answer > goal:
                print("Ваше число більше задуманого")
            elif answer < goal:
                print("Ваше число менше задуманого")
            else:
                print(f"Вітаємо! Ви вгадали число за {count} кроків")
                break


    def inverted_game():
        while True:
            goal = int(input(f"Загадайте задумане число від 0 до 100: "))
            if goal < 0 or goal > 100:
                continue
            else:
                break
        count = 0
        for _ in range(10):
            answer = randint(1, 100)
            count += 1
            if answer == goal:
                print(f"Ура! Я вгадав число за {count} кроків")
                break
            print(f"Чи це {answer}? Ні :(")
        else:
            print("Я програв(")


    def inverted_game_smarter():
        while True:
            goal = int(input(f"Загадайте задумане число від 0 до 100: "))
            if goal < 0 or goal > 100:
                continue
            else:
                break
        count = 0
        answers = sample(range(1, 101), 10)
        for answer in answers:
            count += 1
            if answer == goal:
                print(f"Ура! Я вгадав число за {count} кроків")
                break
            else:
                print(f"Чи це {answer}? Ні :(")
        else:
            print("Я програв(")

    game()
    inverted_game()
    inverted_game_smarter()


if __name__ == '__main__':
    task_4()