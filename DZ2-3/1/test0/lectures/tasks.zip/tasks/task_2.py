"""
2. Напишіть функцію, що приймає два числа і вертає перше число в степені другого (без використання вбудованого функціоналу, але можна використовувати множення)
2*. Напишіть ту ж функцію, але використовуючи рекурсію.
"""
def task_2(base, exp):
    def my_pow_using_for(base, exp):
        result = 1
        for _ in range(exp):
            result *= base
        return result

    def my_pow_using_recursion(base, exp):
        if exp == 0:
            return 1
        if exp == 1:
            return base
        return base * my_pow_using_recursion(base, exp-1)
    
    return my_pow_using_for(base, exp), my_pow_using_recursion(base, exp)


try:
    print(task_2(int(input()), int(input())))
except ValueError as e:
    print(e)