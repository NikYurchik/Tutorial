"""
1. Напишіть функцію, яка буде приймати число і рекурсивно виводити число і відповідну кількість зірочок, поступово зменшуючи кількість на 2 (поки не дійдемо до нуля). Наприклад, якщо ввести 5, отримаємо такий результат
5 *****
3 ***
1 *

1*. Напишіть ту ж функцію, але використовуючи рекурсію.
"""
def task_1(num):
    def print_stars_using_for(num):
        while num > 0:
            print(num, "*" * num)
            num -= 2


    def print_stars_using_recursion(num):
        if num > 0:
            print(num, "*" * num)
            print_stars_using_recursion(num-2)
        else:
            return
    
    print_stars_using_for(num)
    print_stars_using_recursion(num)

try:
    task_1(int(input()))
except ValueError as e:
    print(e)
